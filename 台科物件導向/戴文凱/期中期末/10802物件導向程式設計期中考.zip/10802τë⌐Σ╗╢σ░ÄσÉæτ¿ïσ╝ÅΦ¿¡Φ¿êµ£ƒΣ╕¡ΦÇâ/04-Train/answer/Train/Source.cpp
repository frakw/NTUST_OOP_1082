#include "Train.h"

int main(void)
{
	Train t;
	t.inputTrain();
	t.printTrain();

	return 0;
}
