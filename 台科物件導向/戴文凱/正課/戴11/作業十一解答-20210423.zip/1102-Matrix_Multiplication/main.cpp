#include<iostream>

using namespace std;

void inputMatrix(int, int, int*);
void multiplyMatrix(int, int, int*, int, int, int*, int*);
void outputMatirx(int, int, int*);

int main(void) {
	int colA, rowA, colB, rowB;
	int *A, *B;
	while (cin >> rowA >> colA >> rowB >> colB) {
		A = new int[rowA * colA];
		B = new int[rowB * colB];
		inputMatrix(rowA, colA, A);
		inputMatrix(rowB, colB, B);
		if (colA == rowB) {
			int *C = new int[rowA * colB];
			multiplyMatrix(rowA, colA, A, rowB, colB, B, C);
			outputMatirx(rowA, colB, C);
			delete[] C;
		}
		else {
			cout << "Matrix multiplication failed." << endl;
		}
		delete[] A;
		delete[] B;
	}
	return 0;
}

void inputMatrix(int row, int col, int* mat) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			cin >> mat[i * col + j];
		}
	}
	return;
}
void multiplyMatrix(int rowA, int colA, int* A, int rowB, int colB, int* B, int* C) {
	for (int i = 0; i < rowA; i++) {
		for (int j = 0; j < colB; j++) {
			int sum = 0;
			for (int k = 0; k < colA; k++) {
				sum += A[i * colA + k] * B[k * colB + j];
			}
			C[i * colB + j] = sum;
		}
	}
}
void outputMatirx(int row, int col, int* mat) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			cout << mat[i * col + j];
			if (j != col - 1)
				cout << " ";
			else
				cout << endl;
		}
	}
}