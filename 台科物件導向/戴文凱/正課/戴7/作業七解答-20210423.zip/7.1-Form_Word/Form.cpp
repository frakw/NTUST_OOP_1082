#include "Form.h"
#include<iostream>
#include<algorithm>
#include<fstream>

void Form::SetInputWord(string inputWord){
	this->input = inputWord;
}

void Form::ProcessInputWord(){
	for (int i = 0; i < 26; i++) {
		alpha1[i] = 0;
	}
	for (int i = 0; i < this->input.length(); i++) {
		alpha1[tolower(this->input[i]) - 97]++;
	}
}

void Form::SetFileName(string fileName){
	this->fileName = fileName;
}

void Form::Load_CompareWord(){
	output.clear();
	ifstream in(this->fileName);
	string data = "";
	int alpha2[26];
	bool flag = true, has = true;
	if (in) {
		while (getline(in, data)) {
			if (flag)
				for (int i = 0; i < 26; i++)
					alpha2[i] = alpha1[i];
			has = true;
			flag = false;
			for (int i = 0; i < data.length(); i++) {
				int a = tolower(data[i]) - 97;
				if (alpha2[a] == 0) {
					has = false;
					break;
				}
				else {
					alpha2[a]--;
					flag = true;
				}
			}
			if (has) {
				output.push_back(data);
			}
		}
		in.close();
	}
}

void Form::PrintFoundWords(){
	for (int i = 0; i < output.size(); i++)
		cout << output[i] << endl;
}
