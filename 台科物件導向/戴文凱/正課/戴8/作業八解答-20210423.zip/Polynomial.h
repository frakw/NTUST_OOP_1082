#pragma once
class Polynomial
{
private:
	int size;
	double *parameter;
	Polynomial AddSup(const Polynomial&poly1, const Polynomial&poly2);
public:
	Polynomial();
	Polynomial(double *param, int size);	
	Polynomial(const Polynomial&poly);
	~Polynomial();
	int mySize();
	friend double evaluate(const Polynomial&poly, const double&var);
	double &operator[](const int &index);
	Polynomial operator+(const Polynomial&poly);
	Polynomial operator+(const double&constant);
	friend Polynomial operator+(const double&constant, const Polynomial&poly);
	Polynomial operator-(const Polynomial&poly);
	Polynomial operator-(const double&constant);
	friend Polynomial operator-(const double&constant, const Polynomial&poly);
	Polynomial operator*(const Polynomial&poly);
	Polynomial operator*(const double&constant);
	friend Polynomial operator*(const double&constant, const Polynomial&poly);
	Polynomial &operator=(const Polynomial&poly);
};

