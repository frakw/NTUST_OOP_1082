#include "Polynomial.h"
#include<iostream>

Polynomial Polynomial::AddSup(const Polynomial & poly1, const Polynomial & poly2) {
	Polynomial tmp(poly1);
	for (int i = 0; i < poly2.size; i++)
		*(tmp.parameter + i) += *(poly2.parameter + i);
	return tmp;
}

Polynomial::Polynomial(){
	this->size = 0;
	this->parameter = new double[1];
	*(this->parameter) = 0;
}

Polynomial::Polynomial(double * param, int size){
	this->size = size;
	this->parameter = new double[size];
	for (int i = 0; i < size; i++)
		*(this->parameter + i) = *(param + i);
}

Polynomial::Polynomial(const Polynomial & poly) {
	this->size = poly.size;
	this->parameter = new double[this->size];
	for (int i = 0; i < this->size; i++)
		*(this->parameter + i) = *(poly.parameter + i);
}

Polynomial::~Polynomial() {
	if (this->parameter != nullptr)
		delete parameter;
}

int Polynomial::mySize() {
	return this->size;
}

double & Polynomial::operator[](const int &index) {
	if (index >= this->size) {
		std::cout << "Index Out Of Range!\n";
		double tmp = -1;
		return tmp;
	}
	return *(this->parameter + index);
}

Polynomial Polynomial::operator+(const Polynomial & poly) {
	if (this->size > poly.size)
		return AddSup(*this, poly);
	else
		return AddSup(poly, *this);
}

Polynomial Polynomial::operator+(const double & constant) {
	Polynomial tmp(*this);
	*(tmp.parameter) += constant;
	return tmp;
}

Polynomial Polynomial::operator-(const Polynomial & poly) {
	return *(this) + -1 * poly;
}

Polynomial Polynomial::operator-(const double & constant) {
	Polynomial tmp(*this);
	*(tmp.parameter) -= constant;
	return tmp;
}

Polynomial Polynomial::operator*(const Polynomial & poly) {
	int newSize = this->size + poly.size - 1;
	double *param = new double[newSize];
	for (int i = 0; i < newSize; i++)
		*(param + i) = 0;
	for (int i = 0; i < this->size; i++)
		for (int j = 0; j < poly.size; j++)
			*(param + i + j) += *(this->parameter + i)**(poly.parameter + j);
	Polynomial tmp(param, newSize);
	return tmp;
}

Polynomial Polynomial::operator*(const double & constant) {
	Polynomial tmp(*this);
	for (int i = 0; i < tmp.size; i++)
		*(tmp.parameter + i) *= constant;
	return tmp;
}

double evaluate(const Polynomial & poly, const double & var){
	double value = 0;
	double var2 = 1;
	for (int i = 0; i < poly.size; i++, var2 *= var)
		value += *(poly.parameter + i)*var2;
	return value;
}

Polynomial operator+(const double & constant, const Polynomial & poly) {
	Polynomial tmp(poly);
	*(tmp.parameter) += constant;
	return tmp;
}

Polynomial operator-(const double & constant, const Polynomial & poly) {
	Polynomial tmp(poly);
	*(tmp.parameter) -= constant;
	return tmp;
}

Polynomial operator*(const double & constant, const Polynomial & poly) {
	Polynomial tmp(poly);
	for (int i = 0; i < tmp.size; i++)
		*(tmp.parameter + i) *= constant;
	return tmp;
}

Polynomial &Polynomial::operator=(const Polynomial & poly) {
	this->size = poly.size;
	if (this->parameter != NULL)delete this->parameter;
	this->parameter = new double[this->size];
	for (int i = 0; i < poly.size; i++)
		*(this->parameter + i) = *(poly.parameter + i);
	return *this;
}