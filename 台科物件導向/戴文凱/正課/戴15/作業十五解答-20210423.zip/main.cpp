#include <set>
#include <iostream>
#include <string>

using namespace std;

int main(){	
	string input;
	set<string> mySet;
	while (cin >> input)
	{
		if(!mySet.count(input))
			mySet.insert(input);
	}

	set<string>::iterator it;

    for(it = mySet.begin(); it != mySet.end(); it++) 
    cout << (*it) << endl;

	return 0;
}