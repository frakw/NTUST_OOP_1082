#include "Complex.h"

Complex::Complex()
{
	realValue = 0;
	imaginaryValue = 0;
}
Complex::Complex(double r)
{
	realValue = r;
	imaginaryValue = 0;
}
Complex::Complex(double r, double i)
{
	realValue = r;
	imaginaryValue = i;
}
double Complex::real()
{
	return realValue;
}
double Complex::imag()
{
	return imaginaryValue;
}
double Complex::norm()
{	
	return sqrt(realValue*realValue + imaginaryValue*imaginaryValue);
}
double real(Complex c)
{
	return c.real();
}
double imag(Complex c)
{
	return c.imag();
}
double norm(Complex c)
{
	return c.norm();
}
bool operator==(Complex c1, Complex c2)
{
	if (c1.realValue == c2.imaginaryValue && c1.imaginaryValue == c2.imaginaryValue)
		return true;
	else
		return false;
}

Complex Complex::operator+(Complex c)
{
	Complex newc;
	newc.realValue = this->realValue + c.realValue;
	newc.imaginaryValue = this->imaginaryValue + c.imaginaryValue;
	return newc;
}
Complex operator+(double d, Complex c)
{
	Complex newc;
	newc.realValue = d + c.realValue;
	newc.imaginaryValue = c.imaginaryValue;
	return newc;
}
Complex Complex::operator-(Complex c)
{
	Complex newc;
	newc.realValue = this->realValue - c.realValue;
	newc.imaginaryValue = this->imaginaryValue - c.imaginaryValue;
	return newc;
}
Complex operator-(double d,Complex c)
{
	Complex newc;
	newc.realValue = d - c.realValue;
	newc.imaginaryValue = c.imaginaryValue;
	return newc;
}
Complex Complex::operator*(Complex c)
{
	Complex newc;
	newc.realValue = this->realValue * c.realValue;
	newc.realValue += -(this->imaginaryValue*c.imaginaryValue);		
	newc.imaginaryValue += this->realValue*c.imaginaryValue;
	newc.imaginaryValue += this->imaginaryValue*c.realValue;
	return newc;
}
Complex operator*(double d,Complex c)
{
	Complex newc;
	newc.realValue = d * c.realValue;	
	newc.imaginaryValue = d * c.imaginaryValue;	
	return newc;
}
Complex Complex::operator/(Complex c)
{
	Complex newc;
	newc.realValue = (this->realValue * c.realValue + this->imaginaryValue * c.imaginaryValue)/(c.realValue*c.realValue+c.imaginaryValue*c.imaginaryValue);
	newc.imaginaryValue = (-this->realValue*c.imaginaryValue+ this->imaginaryValue*c.realValue)/ (c.realValue*c.realValue + c.imaginaryValue*c.imaginaryValue);
	return newc;
}
Complex operator/(double d,Complex c)
{
	Complex newc;
	newc.realValue = (d * c.realValue + 0 * c.imaginaryValue) / (c.realValue*c.realValue + c.imaginaryValue*c.imaginaryValue);
	newc.imaginaryValue = (-d*c.imaginaryValue + 0*c.realValue) / (c.realValue*c.realValue + c.imaginaryValue*c.imaginaryValue);
	return newc;
}
ostream& operator<<(ostream &strm, const Complex &c) {
	return strm << c.realValue << " + " << c.imaginaryValue << "*i" << "\n";
}
istream& operator>>(istream &is,Complex &c) {
	char inputText[80] = {""};
	is >> inputText;
	is >> inputText;
	is >> inputText;	
	c.realValue = atof(inputText);
	is >> inputText;
	is >> inputText;	
	c.imaginaryValue = atof(strncpy(inputText,inputText,strlen(inputText)-2));
	return is;
}