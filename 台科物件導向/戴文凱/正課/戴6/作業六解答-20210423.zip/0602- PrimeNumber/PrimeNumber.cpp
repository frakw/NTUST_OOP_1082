#include <iostream>
#include "PrimeNumber.h"

bool IsPrime(int n) {
	bool ans = true;

	for (int i = 2; i <= n / 2; ++i)
	{
		if (n % i == 0)
		{
			ans = false;
			break;
		}
	}

	return ans;
}

PrimeNumber::PrimeNumber() {
	value = 1;
}

PrimeNumber::PrimeNumber(int _value) {
	value = _value;
}

int PrimeNumber::get() {
	return value;
}

PrimeNumber & PrimeNumber::operator++() {
	while (1) {
		this->value++;
		if (IsPrime(this->value))
			break;
	}
	return *this;
}

PrimeNumber PrimeNumber::operator++(int) {
	int old = this->value;

	while (1) {
		this->value++;
		if (IsPrime(this->value))
			break;
	}
	return PrimeNumber(old);
}

PrimeNumber & PrimeNumber::operator--() {
	
	if (this->value == 2) {
		this->value = 1;
		return *this;
	}

	while (1) {
		this->value--;
		if (IsPrime(this->value))
			break;
	}
	return *this;
}

PrimeNumber PrimeNumber::operator--(int) {

	int old = this->value;

	if (this->value == 2) {
		this->value = 1;
		return *this;
	}

	while (1) {
		this->value--;
		if (IsPrime(this->value))
			break;
	}
	return PrimeNumber(old);
}

